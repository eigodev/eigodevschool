package com.eigodev.home_teachers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeTeachersApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeTeachersApplication.class, args);
	}

}
