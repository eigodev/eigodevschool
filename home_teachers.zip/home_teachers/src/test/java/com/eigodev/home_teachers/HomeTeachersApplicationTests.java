package com.eigodev.home_teachers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeTeachersApplicationTests {

	@Test
	void contextLoads() {
	}

}
